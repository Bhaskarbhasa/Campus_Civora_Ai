const nodemailer = require("nodemailer");
const config = require("../config");

/**
 * Create Email Transporter
 */
const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: config.emailUser,
        pass: config.emailPassword,
    },
});

/**
 * Send OTP Email
 */
const sendOtpEmail = async (email, otp) => {

    const mailOptions = {
        from: config.emailUser,
        to: email,
        subject: "Campus CIVORA AI - Email Verification OTP",

        html: `
            <h2>Email Verification</h2>

            <p>Your OTP for verifying your account is:</p>

            <h1>${otp}</h1>

            <p>This OTP is valid for 5 minutes.</p>

            <p>If you did not request this OTP, please ignore this email.</p>
        `,
    };

    await transporter.sendMail(mailOptions);
};

module.exports = {
    sendOtpEmail,
};