const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const userRepository = require("../repositories/user.repository");
const otpService = require("./otp.service");

const { sendOtpEmail } = require("../utils/email");
const ApiError = require("../utils/ApiError");

const registerUser = async (userData) => {

    const session = await mongoose.startSession();

    try {

        session.startTransaction();

        // Check if email already exists
        const existingUser = await userRepository.findUserByEmail(
            userData.email
        );

        if (existingUser) {
            throw new ApiError(
                409,
                "Email already exists"
            );
        }

        // Hash Password
        const hashedPassword = await bcrypt.hash(
            userData.password,
            10
        );

        userData.password = hashedPassword;

        // Create User
        const user = await userRepository.createUser(
            userData,
            session
        );

        // Create OTP
        const otp = await otpService.createOtp(
            user.email,
            session
        );

        // Commit Transaction
        await session.commitTransaction();
        session.endSession();

        // Send Email
        await sendOtpEmail(
            user.email,
            otp
        );

        return {
            email: user.email,
        };

    } catch (error) {

        await session.abortTransaction();
        session.endSession();

        throw error;
    }
};

const loginUser = async (loginData) => {

    // Find User (including password)
    const user = await userRepository.findUserByEmailWithPassword(
        loginData.email
    );

    if (!user) {
        throw new ApiError(
            401,
            "Invalid Email or Password"
        );
    }

    // Check account status
    if (!user.isActive) {
        throw new ApiError(
            403,
            "Your account has been deactivated."
        );
    }

    // Check email verification
    if (!user.isVerified) {
        throw new ApiError(
            403,
            "Please verify your email before logging in."
        );
    }

    // Compare Password
    const isPasswordValid = await bcrypt.compare(
        loginData.password,
        user.password
    );

    if (!isPasswordValid) {
        throw new ApiError(
            401,
            "Invalid Email or Password"
        );
    }

    // Update last login
    await userRepository.updateLastLogin(user._id);

    // Generate JWT
    const token = jwt.sign(
        {
            id: user._id,
            email: user.email,
            role: user.role,
        },
        process.env.JWT_SECRET,
        {
            expiresIn: "1d",
        }
    );

    return {
        token,
        user: {
            id: user._id,
            fullName: user.fullName,
            email: user.email,
            role: user.role,
            isVerified: user.isVerified,
        },
    };
};

module.exports = {
    registerUser,
    loginUser,
};