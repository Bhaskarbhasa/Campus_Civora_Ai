const authService = require("../services/auth.service");
const otpService = require("../services/otp.service");

const ApiResponse = require("../utils/ApiResponse");
const asyncHandler = require("../utils/asyncHandler");

/**
 * Register User
 */
const register = asyncHandler(async (req, res) => {

    const result = await authService.registerUser(
        req.body
    );

    return res.status(201).json(

        new ApiResponse(

            201,

            "Registration successful. Please verify your email using the OTP sent to your inbox.",

            result

        )

    );

});

/**
 * Login User
 */
const login = asyncHandler(async (req, res) => {

    const result = await authService.loginUser(
        req.body
    );

    return res.status(200).json(

        new ApiResponse(

            200,

            "Login Successful",

            result

        )

    );

});

/**
 * Verify OTP
 */
const verifyOtp = asyncHandler(async (req, res) => {

    const { email, otp } = req.body;

    const result = await otpService.verifyOtp(
        email,
        otp
    );

    return res.status(200).json(

        new ApiResponse(

            200,

            result.message,

            null

        )

    );

});

module.exports = {

    register,

    login,

    verifyOtp,

};