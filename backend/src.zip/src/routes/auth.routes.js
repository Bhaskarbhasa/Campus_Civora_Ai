const express = require("express");

const router = express.Router();

const authController = require("../controllers/auth.controller");

const {
    registerValidation,
    loginValidation,
    verifyOtpValidation,
    validate,
} = require("../validations/auth.validation");

router.post(
    "/register",
    registerValidation,
    validate,
    authController.register
);

router.post(
    "/login",
    loginValidation,
    validate,
    authController.login
);

router.post(
    "/verify-otp",
    verifyOtpValidation,
    validate,
    authController.verifyOtp
);

module.exports = router;